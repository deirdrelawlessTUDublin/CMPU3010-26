/*
    CMPU3010 Databases 2
    Week 3 Lab
    Student Starter File

    Name:
    Student number:
    Lab group: A / B / C / D

    Run the supplied queries, complete each task and write your answers
    in the comment spaces provided. Retain your completed file for
    Lab Submission 1.
*/

-- Use the CommunityCare schema for this session.
SET search_path TO communitycare, public;


/* ================================================================
   PART A - WINDOW FUNCTIONS
   ================================================================ */


/* ----------------------------------------------------------------
   A1. RANK
   Display each patient's appointments and rank them by date.
   ---------------------------------------------------------------- */

SELECT
    p.first_name,
    p.last_name,
    a.appointment_id,
    a.appointment_date,
    a.appointment_time,
    RANK() OVER (
        PARTITION BY a.patient_id
        ORDER BY a.appointment_date
    ) AS appointment_rank
FROM patient AS p
JOIN appointment AS a
    ON p.patient_id = a.patient_id
ORDER BY
    a.patient_id,
    a.appointment_date,
    a.appointment_time;

/*
    Questions

    1. Where does the ranking restart?
       Answer:

    2. What happens when a patient has two appointments on the same date?
       Answer:

    3. Why can there be a gap after tied rows?
       Answer:
*/


/* ----------------------------------------------------------------
   A2. Comparing RANK and DENSE_RANK

   Extend the A1 query to include the following expression.
   ---------------------------------------------------------------- */

/*
    DENSE_RANK() OVER (
        PARTITION BY a.patient_id
        ORDER BY a.appointment_date
    ) AS dense_appointment_rank
*/

-- Write the complete A2 query below.



/*
    Identify a patient with two appointments on the same date and
    explain the difference between RANK and DENSE_RANK.

    Answer:
*/


/* ----------------------------------------------------------------
   A3. LEAD
   Show the next appointment date for each patient.
   ---------------------------------------------------------------- */

SELECT
    p.first_name,
    p.last_name,
    a.appointment_id,
    a.appointment_date,
    a.appointment_time,
    LEAD(a.appointment_date) OVER (
        PARTITION BY a.patient_id
        ORDER BY
            a.appointment_date,
            a.appointment_time,
            a.appointment_id
    ) AS next_appointment_date
FROM patient AS p
JOIN appointment AS a
    ON p.patient_id = a.patient_id
ORDER BY
    a.patient_id,
    a.appointment_date,
    a.appointment_time;

/*
    Questions

    1. Why does the final appointment for each patient return NULL?
       Answer:

    2. Why are date, time and appointment ID included in the window
       ordering?
       Answer:

    3. Does the final ORDER BY determine which row LEAD returns?
       Answer:
*/


/* ----------------------------------------------------------------
   A4. TASK

   Extend the A3 query to show:
   - the next appointment date;
   - the next appointment time;
   - the next appointment status.

   Use three LEAD expressions with the same window definition.
   ---------------------------------------------------------------- */

-- Write the complete A4 query below.



/* ----------------------------------------------------------------
   A5. Aggregate function with OVER
   Show each appointment and the total appointments for that patient.
   ---------------------------------------------------------------- */

SELECT
    appointment_id,
    patient_id,
    appointment_date,
    COUNT(*) OVER (
        PARTITION BY patient_id
    ) AS patient_appointment_count
FROM appointment
ORDER BY patient_id, appointment_date, appointment_id;

/*
    Questions

    1. Why is the count repeated for every appointment belonging to
       the same patient?
       Answer:

    2. How would the result differ if the query used COUNT(*) with
       GROUP BY patient_id?
       Answer:
*/


/* ================================================================
   PART B - SUBQUERIES
   ================================================================ */


/* ----------------------------------------------------------------
   B1. IN
   Find patients who have at least one completed appointment.
   ---------------------------------------------------------------- */

SELECT
    patient_id,
    first_name,
    last_name
FROM patient
WHERE patient_id IN (
    SELECT patient_id
    FROM appointment
    WHERE status = 'Completed'
);

-- Run the inner query separately and inspect the returned patient IDs.


/* ----------------------------------------------------------------
   B2. TASK
   Find services that have been used in cancelled appointments.
   ---------------------------------------------------------------- */

-- Write the B2 query below.



/* ----------------------------------------------------------------
   B3. EXISTS
   Find patients who have at least one scheduled appointment.
   ---------------------------------------------------------------- */

SELECT
    p.patient_id,
    p.first_name,
    p.last_name
FROM patient AS p
WHERE EXISTS (
    SELECT 1
    FROM appointment AS a
    WHERE a.patient_id = p.patient_id
      AND a.status = 'Scheduled'
);

/*
    The subquery is correlated through p.patient_id.
    EXISTS checks whether a matching row is present.
    SELECT 1 does not return the number 1 to the outer query.
*/


/* ----------------------------------------------------------------
   B4. NOT EXISTS
   Find patients who have never had a cancelled appointment.
   ---------------------------------------------------------------- */

SELECT
    p.patient_id,
    p.first_name,
    p.last_name
FROM patient AS p
WHERE NOT EXISTS (
    SELECT 1
    FROM appointment AS a
    WHERE a.patient_id = p.patient_id
      AND a.status = 'Cancelled'
);


/* ----------------------------------------------------------------
   B5. TASK
   Find staff members who have conducted at least one completed
   appointment. Use a correlated EXISTS subquery rather than a join.
   ---------------------------------------------------------------- */

-- Write the B5 query below.



/* ----------------------------------------------------------------
   B6. TASK
   Find services that have never been used for an appointment.
   Use a correlated NOT EXISTS subquery rather than a join.
   ---------------------------------------------------------------- */

-- Write the B6 query below.



/* ================================================================
   PART C - IN VERSUS EXISTS
   ================================================================ */


/* Using IN */

SELECT
    patient_id,
    first_name,
    last_name
FROM patient
WHERE patient_id IN (
    SELECT patient_id
    FROM appointment
    WHERE status = 'Completed'
);


/* Using EXISTS */

SELECT
    p.patient_id,
    p.first_name,
    p.last_name
FROM patient AS p
WHERE EXISTS (
    SELECT 1
    FROM appointment AS a
    WHERE a.patient_id = p.patient_id
      AND a.status = 'Completed'
);

/*
    Questions

    1. Do the queries produce the same result?
       Answer:

    2. Which subquery can run independently?
       Answer:

    3. Which subquery refers to the current patient?
       Answer:

    4. Why does the outer query return each patient only once?
       Answer:
*/


/* ================================================================
   PART D - LAB SUBMISSION 1 TASK

   Complete only the task allocated to your lab group.
   Include short comments in your own words that explain:
   - the purpose of the report;
   - the tables joined and the purpose of the join;
   - PARTITION BY and the window ORDER BY;
   - COUNT with OVER;
   - how the subquery filters the report.
   ================================================================ */


/* ----------------------------------------------------------------
   GROUP A

   Produce a report showing:
   - the patient's name;
   - the appointment date and time;
   - the appointment's rank by date for that patient, with the earliest
     date ranked first;
   - the next appointment date for that patient;
   - the total number of appointments for that patient;
   - only patients who have at least one completed appointment.

   You must use:
   - a join between patient and appointment;
   - RANK();
   - LEAD();
   - COUNT(*) OVER (PARTITION BY a.patient_id);
   - a correlated subquery with EXISTS.
   ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
   GROUP B

   Produce a report showing:
   - the staff member's name;
   - the appointment date and time;
   - the appointment's rank by date for that staff member, with the
     earliest date ranked first;
   - the next appointment date for that staff member;
   - the total number of appointments for that staff member;
   - only staff members who have at least one scheduled appointment.

   You must use:
   - a join between staff and appointment;
   - RANK();
   - LEAD();
   - COUNT(*) OVER (PARTITION BY a.staff_id);
   - a subquery with IN.
   ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
   GROUP C

   Produce a report showing:
   - the service name;
   - the appointment date and time;
   - the appointment's rank by date for that service, with the most
     recent date ranked first;
   - the chronologically previous appointment date for that service;
   - the total number of appointments for that service;
   - only services that have never had a cancelled appointment.

   You must use:
   - a join between service and appointment;
   - RANK();
   - LEAD() with descending date order;
   - COUNT(*) OVER (PARTITION BY a.service_id);
   - a correlated subquery with NOT EXISTS.
   ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
   GROUP D

   Produce a report showing:
   - the patient's name;
   - the appointment date and time;
   - the appointment's rank by date for that patient, with the most
     recent date ranked first;
   - the chronologically previous appointment date for that patient;
   - the total number of appointments for that patient;
   - only patients who have at least one appointment on or after
     1 April 2026.

   You must use:
   - a join between patient and appointment;
   - RANK();
   - LEAD() with descending date order;
   - COUNT(*) OVER (PARTITION BY a.patient_id);
   - a subquery with IN.
   ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
   Write your allocated Part D solution below.
   ---------------------------------------------------------------- */

/*
    Purpose of the report:

    Join explanation:

    Window-function explanation:

    COUNT with OVER explanation:

    Subquery explanation:
*/


-- Write the completed Part D query below (appropriately commented).

